﻿using System;
using System.Text;

namespace CodingChallenge
{
    /// <summary>
    /// This program takes user input, then encrypts that data using a one-time pad encryption algorithm,
    /// then displays the encrypted data to the user before decrypting and displaying that data to the user.
    /// </summary>
    class Program
    {
        static void Main(string[] args)
        {
            var p = new Program();//init
            p.start();
        }

        /**
         * Starts everything in motion
         * */
        private void start()
        {
            Console.Clear();
            Console.Write("Please enter text to encrypt: ");
            string plainText = getStringInput();//get user input for plaintext
            Console.Write("Please enter a key length (enter 0 to have it the same length as your text): ");
            int keyLength = getIntInput();//get user input for key length
            if (plainText != null)//shouldn't be null, but just incase
            {
                CypherKeyPair pair;
                string result;
                if (keyLength > 0)//if the user selected to have a custom key length:
                {
                    pair = EncryptDecrypt.encryptKnownKeyLength(plainText, keyLength);//encrypt the data
                    result = EncryptDecrypt.decryptKnownKeyLength(pair);//decrypt the data
                }
                else//else if they want the default length which is equal to the length of the plaintext:
                {
                    pair = EncryptDecrypt.encrypt(plainText);//encrypt the data
                    result = EncryptDecrypt.decrypt(pair);//decrypt the data
                }
                Console.WriteLine("\r\nOriginal text: " + plainText + "\r\nKey: " + Encoding.UTF8.GetString(pair.key) +
                    "\r\nCyphertext: " + Encoding.UTF8.GetString(pair.cypherText) + "\r\n");//print result of encryption
                Console.WriteLine("Decrypted cyphertext: " + result);//print result of decryption
            }
            Console.Write("Do you wish to encrypt more text (Y/N)? ");
            string response = Console.ReadLine();//wait for user input (keeps things on the display)
            if (response.Equals("Y", StringComparison.InvariantCultureIgnoreCase)) start();
        }

        /**
         * Function to get the input from the user and check that it's valid
         * Returns input string
         * */
        private string getStringInput()
        {
            try//check if the text entered is capable of being turned into a string
            {
                string text = Console.ReadLine();
                if (string.IsNullOrEmpty(text))//if string is empty or null for some reason, get user to try again through recursion
                {
                    Console.Write("Please enter text to encrypt: ");
                    getStringInput();
                }
                else
                {
                    return text;
                }
            }
            catch(Exception ex)//if an error appeared, catch and try again
            {
                Console.Write("That is not a valid string, please enter new text: ");
                getStringInput();
            }
            return null;//if somehow breaks recursion and ends up here, return nothing
        }

        /**
         * Function to get the user input and check if it's a valid number
         * Returns input value as integer
         * */
        private int getIntInput()
        {
            try
            {
                int length = Convert.ToInt32(Console.ReadLine());
                return length;
            }catch
            {
                Console.Write("That is not a valid number, please enter a number: ");
                getIntInput();
            }
            return 0;//if code reaches here, something probably went wrong
        }


    }
}
