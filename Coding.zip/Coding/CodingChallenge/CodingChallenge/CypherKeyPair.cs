﻿namespace CodingChallenge
{
    /**
     * Structure for storing keys and cypher text
     * */
    public struct CypherKeyPair
    {
        public byte[] cypherText;
        public byte[] key;
    }
}
