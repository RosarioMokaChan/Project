﻿using System;
using System.Security.Cryptography;
using System.Text;

namespace CodingChallenge
{
    static class EncryptDecrypt
    {
        /**
         * Function to encrypt a string by generating a key of same length and performing one time pad encryption
         * Returns CypherTextPair containing byte arrays of cypher text and key
         * */
        public static CypherKeyPair encrypt(String input)
        {
            RNGCryptoServiceProvider randGen = new RNGCryptoServiceProvider();//secure random number generator
            byte[] key = new byte[input.Length];//key used to encrypt plain text
            byte[] cypherText = new byte[input.Length];//stores result of the encryption
            randGen.GetBytes(key);//fill byte array with random values
            for (int i = 0; i < input.Length; i++)
            {
                cypherText[i] = (byte)(input[i] ^ key[i]);//perform bitwise XOR on all bytes in array
            }
            CypherKeyPair pair = new CypherKeyPair();//struct to store results
            pair.cypherText = cypherText;
            pair.key = key;
            return pair;//return cyphertext and key
        }

        /**
         * Function to encrypt plaintext using a predefined key length. In this function, the entire key is used on each byte of the input text rather than just one byte
         * Returns CypherTextPair containing byte arrays of cypher text and key
         * */
        public static CypherKeyPair encryptKnownKeyLength(String input, int keyLength)
        {
            RNGCryptoServiceProvider randGen = new RNGCryptoServiceProvider();//secure random number generator
            byte[] key = new byte[keyLength];//key used to encrypt plain text
            byte[] cypherText = new byte[input.Length];//stores result of the encryption
            randGen.GetBytes(key);//fill byte array with random values
            for (int i = 0; i < input.Length; i++)
            {
                for(int j = 0; j < key.Length; j ++)//for each character in plaintext, xor with entirety of key
                {
                    cypherText[i] = (byte)(input[i] ^ key[j]);//perform bitwise XOR on all bytes in array
                }
            }
            CypherKeyPair pair = new CypherKeyPair();//struct to store results
            pair.cypherText = cypherText;
            pair.key = key;
            return pair;//return cyphertext and key
        }

        /**
         * Function to decrypt a CypherKeyPair
         * Returns string of decrypted cypher text
         * */
        public static string decrypt(CypherKeyPair pair)
        {
            byte[] result = new byte[pair.cypherText.Length];//set to length of cyphertext
            for (int i = 0; i < pair.cypherText.Length; i++)//loop through cyphertext byte array
            {
                result[i] = (byte)(pair.cypherText[i] ^ pair.key[i]);//perform bitwise XOR on all bytes in array
            }
            return Encoding.UTF8.GetString(result);//convert to string and return
        }

        /**
         * Function to decrypt a CypherKeyPair when the entire key was used to encrypt each byte of the plaintext
         * Returns string of decrypted cypher text
         * */
        public static string decryptKnownKeyLength(CypherKeyPair pair)
        {
            byte[] result = new byte[pair.cypherText.Length];//set to length of cyphertext
            for (int i = 0; i < pair.cypherText.Length; i++)//loop through cyphertext byte array
            {
                for(int j = 0; j < pair.key.Length; j++)//loop through entire key
                result[i] = (byte)(pair.cypherText[i] ^ pair.key[j]);//perform bitwise XOR on all bytes in array
            }
            return Encoding.UTF8.GetString(result);//convert to string and return
        }

    }
}
