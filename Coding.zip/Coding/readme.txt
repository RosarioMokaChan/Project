28/03/2017	Created by Christopher Mallinson in Visual Studio Community 2015

This console application implements a simple one-time pad encryption algorithm and allows a user to enter some text, 
the length for a key, and then the program will encrypt and decrypt the data printing out the results for the key, 
cyphertext, and plaintext. There is validation in place to ensure that the program will not accept incorrect data,
and relevant information is clearly displayed to the user. 

There are 3 .cs files which make up the work that I have done:

-Program.cs, this is the main file for the program, it is in charge of collecting the user input and passing it along,
along with validating user input and displaying results to the user.

-EncryptDecrypt.cs, this file holds the static methods for encryption and decryption. The encyrption methods (one for known
key length, one for default) take the plaintext as a parameter along with the key length if it's not the default length, then
apply the algorithm by performing a bitwise exclusive or to each byte in the plaintext using the key which is generated randomly.
For decryption, a similar approach is taken, however this time it's the cyphertext and key that are passed though and the 
decrypted plaintext is returned. I chose to make these methods static as this class is more of a utility class, and shouldn't
really by modified from the outside (hence why there are no getters/setters).

-CypherKeyPair.cs, a custom structure to make passing the cyphertext and key pairings a little easier.